CREATE VIEW test_join3 AS
  (SELECT
     'Заказчик'                         AS `Роль_организации`,
     `tender`.`od_customer`.`full_name` AS `Полное_наименование`,
     `tender`.`od_customer`.`inn`       AS `ИНН`,
     (SELECT `tnd`.`purchase_number`
      FROM (((`tender`.`tender` `tnd` LEFT JOIN `tender`.`lot`
          ON (`tender`.`lot`.`id_tender` = `tnd`.`id_tender`)) LEFT JOIN `tender`.`customer_requirement` `c_r`
          ON (`c_r`.`id_lot` = `tender`.`lot`.`id_lot`)) LEFT JOIN `tender`.`customer` `cus`
          ON (`cus`.`id_customer` = `c_r`.`id_customer`))
      WHERE `cus`.`reg_num` = `tender`.`od_customer`.`regNumber`
      ORDER BY `tnd`.`doc_publish_date` DESC
      LIMIT 1)                          AS `Идентификатор`,
     (SELECT `tnd_2`.`doc_publish_date`
      FROM `tender`.`tender` `tnd_2`
      WHERE `tnd_2`.`purchase_number` = `Идентификатор`
      ORDER BY `tnd_2`.`doc_publish_date` DESC
      LIMIT 1)                          AS `Дата_последнего_действия`,
     'REGION'                           AS `Рeгион`,
     1                                  AS `Действующий`,
     'Публикация закупки'               AS `Последнее_действие`,
     'Потом добавим'                    AS `Контактные_данные`,
     'Region'                           AS `id_region`
   FROM (`tender`.`od_customer`
     LEFT JOIN `tender`.`od_supplier` ON (`tender`.`od_supplier`.`id` = `tender`.`od_customer`.`id`))
   WHERE `tender`.`od_customer`.`full_name` <> '')
  UNION ALL (SELECT
               'Поставщик'                               AS `Роль_организации`,
               `tender`.`od_supplier`.`organizationName` AS `Полное_наименование`,
               `tender`.`od_supplier`.`inn`              AS `ИНН`,
               (SELECT `cont`.`regnum`
                FROM (`tender`.`od_contract` `cont` LEFT JOIN `tender`.`od_supplier` `sup`
                    ON (`cont`.`id_supplier` = `sup`.`id`))
                WHERE `sup`.`id` = `tender`.`od_supplier`.`id`
                ORDER BY `cont`.`sign_date` DESC
                LIMIT 1)                                 AS `Идентификатор`,
               (SELECT `cont`.`sign_date`
                FROM `tender`.`od_contract` `cont`
                WHERE `cont`.`regnum` = `Идентификатор`
                ORDER BY `cont`.`sign_date` DESC
                LIMIT 1)                                 AS `Дата_последнего_действия`,
               'Region'                                  AS `Рeгион`,
               1                                         AS `Действующий`,
               'Заключение контракта'                    AS `Последнее_действие`,
               'Потом добавим'                           AS `Контактные_данные`,
               'ID REGION'                               AS `id_region`
             FROM (`tender`.`od_supplier`
               LEFT JOIN `tender`.`od_customer` ON (`tender`.`od_customer`.`id` = `tender`.`od_supplier`.`id`))
             WHERE `tender`.`od_supplier`.`organizationName` <> '');
