CREATE VIEW web_nmck_okei AS
  SELECT `product`.`okei` AS `okei`
  FROM `tender2`.`od_contract_product` `product`
  GROUP BY `product`.`okei`;
