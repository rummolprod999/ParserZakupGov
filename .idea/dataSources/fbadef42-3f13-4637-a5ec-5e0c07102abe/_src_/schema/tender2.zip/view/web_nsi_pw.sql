CREATE VIEW web_nsi_pw AS
  SELECT
    `tender2`.`placing_way`.`id_placing_way` AS `id_placing_way`,
    `tender2`.`placing_way`.`code`           AS `code`,
    `tender2`.`placing_way`.`name`           AS `name`,
    `tender2`.`placing_way`.`conformity`     AS `conformity`
  FROM `tender2`.`placing_way`
  GROUP BY `tender2`.`placing_way`.`conformity`;
