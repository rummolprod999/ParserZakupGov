CREATE VIEW web_organizations AS
  SELECT
    'Заказчик'                          AS `Роль_организации`,
    `tender2`.`od_customer`.`full_name` AS `Полное_наименование`,
    `tender2`.`od_customer`.`inn`       AS `ИНН`,
    (SELECT `tnd`.`purchase_number`
     FROM (((`tender2`.`tender` `tnd` LEFT JOIN `tender2`.`lot`
         ON (`tender2`.`lot`.`id_tender` = `tnd`.`id_tender`)) LEFT JOIN `tender2`.`customer_requirement` `c_r`
         ON (`c_r`.`id_lot` = `tender2`.`lot`.`id_lot`)) LEFT JOIN `tender2`.`customer` `cus`
         ON (`cus`.`id_customer` = `c_r`.`id_customer`))
     WHERE `cus`.`id_customer` = `tender2`.`od_customer`.`id`
     ORDER BY `tnd`.`doc_publish_date` DESC
     LIMIT 1)                           AS `Идентификатор`,
    (SELECT `tnd_2`.`doc_publish_date`
     FROM `tender2`.`tender` `tnd_2`
     WHERE `tnd_2`.`purchase_number` = `Идентификатор`
     LIMIT 1)                           AS `Дата_последнего_действия`,
    `tender2`.`region`.`name`           AS `Рагион`,
    1                                   AS `Действующий`,
    'Публикация закупки'                AS `Последнее_действие`,
    'Потом добавим'                     AS `Контактные_данные`,
    `tender2`.`region`.`id`             AS `id_region`
  FROM (`tender2`.`od_customer`
    LEFT JOIN `tender2`.`region` ON (`tender2`.`region`.`conf` = `tender2`.`od_customer`.`region_code`));
