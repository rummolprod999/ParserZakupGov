CREATE VIEW web_proc_tenders AS
  SELECT
    `ten`.`id_tender`                    AS `ten_id`,
    `ten`.`purchase_object_info`         AS `Наименование тендера`,
    `ten`.`purchase_number`              AS `Номер тендера ЕИС`,
    `po`.`okpd2_code`                    AS `Код ОКПД2`,
    `po`.`okpd_name`                     AS `Наименование ОКПД2`,
    `ten`.`doc_publish_date`             AS `Дата публикации тендера`,
    `cus`.`full_name`                    AS `Наименование заказчика`,
    `cus`.`inn`                          AS `ИНН заказчика`,
    `reg`.`name`                         AS `Регион поставки`,
    `reg`.`id`                           AS `region_id`,
    `ten`.`type_fz`                      AS `ФЗ`,
    `tender2`.`lot`.`max_price`          AS `НМЦК`,
    `obs`.`contract_guarantee_amount`    AS `Обеспечение контракта`,
    `obs`.`application_guarantee_amount` AS `Обеспечение заявки`,
    'КБК'                                AS `Код КБК`,
    `pw`.`name`                          AS `Способ закупки`,
    `pw`.`conformity`                    AS `pw_code`,
    `tender2`.`etp`.`name`               AS `ЕЭТП`,
    `ten`.`id_etp`                       AS `etp_id`
  FROM (((((((`tender2`.`tender` `ten` LEFT JOIN `tender2`.`lot`
      ON ((`ten`.`id_tender` = `tender2`.`lot`.`id_tender`))) LEFT JOIN `tender2`.`purchase_object` `po`
      ON ((`tender2`.`lot`.`id_lot` = `po`.`id_lot`))) LEFT JOIN `tender2`.`customer` `cus`
      ON ((`cus`.`id_customer` = `po`.`id_customer`))) LEFT JOIN `tender2`.`placing_way` `pw`
      ON ((`pw`.`id_placing_way` = `ten`.`id_placing_way`))) LEFT JOIN `tender2`.`etp`
      ON ((`tender2`.`etp`.`id_etp` = `ten`.`id_etp`))) LEFT JOIN `tender2`.`region` `reg`
      ON ((`reg`.`id` = `ten`.`id_region`))) LEFT JOIN `tender2`.`customer_requirement` `obs`
      ON ((`obs`.`id_lot` = `tender2`.`lot`.`id_lot`)))
  WHERE (`ten`.`cancel` = 0);
