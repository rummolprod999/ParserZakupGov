CREATE VIEW web_nmck_product AS
  SELECT
    `prod`.`id_od_contract`           AS `contract`,
    `prod`.`name`                     AS `product_name`,
    `prod`.`okpd2_code`               AS `okpd2`,
    `prod`.`okpd_code`                AS `okpd`,
    `prod`.`price`                    AS `price`,
    `prod`.`okpd_name`                AS `okpd_name`,
    `prod`.`quantity`                 AS `quantity`,
    `prod`.`okei`                     AS `okei`,
    `contract`.`region_code`          AS `region_code`,
    `contract`.`sign_date`            AS `sign_date`,
    `contract`.`fz`                   AS `fz`,
    `contract`.`execution_start_date` AS `contract_start`,
    `contract`.`execution_end_date`   AS `contract_end`,
    `contract`.`url`                  AS `oos_url`,
    `prod`.`sum`                      AS `summ`
  FROM ((`tender2`.`od_contract_product` `prod` LEFT JOIN `tender2`.`od_contract` `contract`
      ON (`contract`.`id` = `prod`.`id_od_contract`)) LEFT JOIN `tender2`.`tender` `ten`
      ON (`ten`.`purchase_number` = `contract`.`regnum`))
  WHERE `contract`.`cancel` = 0;
