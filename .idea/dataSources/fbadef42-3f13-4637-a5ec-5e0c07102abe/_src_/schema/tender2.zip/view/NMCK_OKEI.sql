CREATE VIEW NMCK_OKEI AS
  SELECT `product`.`okei` AS `okei`
  FROM `tender2`.`od_contract_product` `product`
  GROUP BY `product`.`okei`;
