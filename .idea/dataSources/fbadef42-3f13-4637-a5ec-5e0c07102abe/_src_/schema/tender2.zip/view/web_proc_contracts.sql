CREATE VIEW web_proc_contracts AS
  SELECT
    `contr`.`id`                         AS `contract_id`,
    `ten`.`purchase_object_info`         AS `Наименование контракта`,
    `contr`.`regnum`                     AS `Номер контракта ЕИС`,
    `prod`.`okpd2_code`                  AS `Код ОКПД2`,
    `prod`.`okpd2_name`                  AS `Наименование ОКПД2`,
    `contr`.`sign_date`                  AS `Дата подписания контракта`,
    `cus`.`full_name`                    AS `Наименование заказчика`,
    `cus`.`inn`                          AS `ИНН заказчика`,
    `sup`.`organizationName`             AS `Наименование победителя`,
    `sup`.`inn`                          AS `ИНН победителя`,
    `_etp`.`name`                        AS `etp_name`,
    `ten`.`id_etp`                       AS `etp_id`,
    `p_w`.`conformity`                   AS `pw_code`,
    `p_w`.`name`                         AS `pw_name`,
    `reg`.`name`                         AS `Регион поставки`,
    `reg`.`id`                           AS `region_id`,
    `contr`.`fz`                         AS `ФЗ`,
    `tender2`.`lot`.`max_price`          AS `НМЦК`,
    `obs`.`contract_guarantee_amount`    AS `Обеспечение контракта`,
    `obs`.`application_guarantee_amount` AS `Обеспечение заявки`,
    'КБК'                                AS `Код КБК`
  FROM (((((((((`tender2`.`od_contract` `contr` LEFT JOIN `tender2`.`od_contract_product` `prod`
      ON ((`contr`.`id` = `prod`.`id_od_contract`))) LEFT JOIN `tender2`.`od_supplier` `sup`
      ON ((`sup`.`id` = `contr`.`id_supplier`))) LEFT JOIN `tender2`.`od_customer` `cus`
      ON ((`cus`.`id` = `contr`.`id_customer`))) LEFT JOIN `tender2`.`tender` `ten`
      ON ((`ten`.`purchase_number` = `contr`.`notification_number`))) LEFT JOIN `tender2`.`lot`
      ON ((`ten`.`id_tender` = `tender2`.`lot`.`id_tender`))) LEFT JOIN `tender2`.`region` `reg`
      ON ((`ten`.`id_region` = `reg`.`id`))) LEFT JOIN `tender2`.`etp` `_etp`
      ON ((`_etp`.`id_etp` = `ten`.`id_etp`))) LEFT JOIN `tender2`.`placing_way` `p_w`
      ON ((`p_w`.`id_placing_way` = `ten`.`id_placing_way`))) LEFT JOIN `tender2`.`customer_requirement` `obs`
      ON ((`obs`.`id_lot` = `tender2`.`lot`.`id_lot`)))
  WHERE ((`contr`.`cancel` = 0) AND (`ten`.`cancel` = 0) AND (`tender2`.`lot`.`lot_number` = `contr`.`lot_number`));
